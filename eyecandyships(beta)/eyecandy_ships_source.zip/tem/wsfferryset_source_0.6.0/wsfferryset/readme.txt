----------------------------
Washington State Ferries Set
----------------------------

This describes when ships will be available in the order they will 
appear. Please note that OpenTTD randomises vehicle availability 
dates by up to two years, so your games may slightly differ.


Beaver
------
Introduction:    1836
Removal:         1876


Fairy
-----
Introduction:    1853
Removal:         1893


Bailey Gatzert
-----
Introduction:    1890
Removal:         1930


Tacoma
------
Introduction:    1913
Removal:         1953


Steel Electric
------
Introduction:    1927
Removal:         1967


Kalakala
--------
Introduction:    1935
Removal:         1975


Rhododendron
------------
Introduction:    1947
Removal:         1997


Jumbo Mk II
-----------
Introduction:    1997
Removal:         NEVER

=====================
       Extras
=====================

Submarine
---------
Introduction:    1960
Removal:         NEVER


Old Jumbo Mk II
-----------
Introduction:    2005
Removal:         NEVER